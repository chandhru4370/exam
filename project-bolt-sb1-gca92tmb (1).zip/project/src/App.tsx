import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ExamProvider } from './contexts/ExamContext';
import { LoginForm } from './components/Auth/LoginForm';
import { RegisterForm } from './components/Auth/RegisterForm';
import { Layout } from './components/Layout';
import { StudentDashboard } from './components/Student/StudentDashboard';
import { TeacherDashboard } from './components/Teacher/TeacherDashboard';

const AuthWrapper: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return isLogin 
      ? <LoginForm onToggleForm={() => setIsLogin(false)} />
      : <RegisterForm onToggleForm={() => setIsLogin(true)} />;
  }

  return (
    <Layout>
      {user.role === 'student' ? <StudentDashboard /> : <TeacherDashboard />}
    </Layout>
  );
};

function App() {
  return (
    <AuthProvider>
      <ExamProvider>
        <AuthWrapper />
      </ExamProvider>
    </AuthProvider>
  );
}

export default App;