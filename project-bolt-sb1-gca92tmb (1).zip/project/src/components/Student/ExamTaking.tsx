import React, { useState, useEffect } from 'react';
import { useExam } from '../../contexts/ExamContext';
import { useFaceDetection } from '../../hooks/useFaceDetection';
import { ExamSession } from '../../types';
import { Clock, AlertTriangle, Eye, Users, Camera, CheckCircle } from 'lucide-react';

interface ExamTakingProps {
  session: ExamSession;
  onComplete: () => void;
}

export const ExamTaking: React.FC<ExamTakingProps> = ({ session, onComplete }) => {
  const { exams, submitAnswer, completeExam } = useExam();
  const { videoRef, proctorStatus, violations, initialize, startDetection, stopDetection, isInitialized } = useFaceDetection();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isExamCompleted, setIsExamCompleted] = useState(false);
  const [showViolationAlert, setShowViolationAlert] = useState(false);

  const exam = exams.find(e => e.id === session.examId);
  const currentQuestion = exam?.questions[currentQuestionIndex];

  useEffect(() => {
    const initializeProctoring = async () => {
      await initialize();
      startDetection();
    };
    
    initializeProctoring();

    return () => {
      stopDetection();
    };
  }, []);

  useEffect(() => {
    if (!exam) return;

    const startTime = new Date(session.startTime).getTime();
    const examDurationMs = exam.duration * 60 * 1000;
    const endTime = startTime + examDurationMs;

    const timer = setInterval(() => {
      const now = Date.now();
      const remaining = Math.max(0, endTime - now);
      setTimeRemaining(Math.floor(remaining / 1000));

      if (remaining <= 0) {
        handleCompleteExam();
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [exam, session]);

  useEffect(() => {
    if (currentQuestion && session.answers[currentQuestion.id] !== undefined) {
      setSelectedAnswer(session.answers[currentQuestion.id]);
    } else {
      setSelectedAnswer(null);
    }
  }, [currentQuestionIndex, currentQuestion, session.answers]);

  useEffect(() => {
    if (proctorStatus.lastViolation) {
      setShowViolationAlert(true);
      setTimeout(() => setShowViolationAlert(false), 5000);
    }
  }, [proctorStatus.lastViolation]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerSelect = (answerIndex: number) => {
    if (!currentQuestion) return;
    
    setSelectedAnswer(answerIndex);
    submitAnswer(session.id, currentQuestion.id, answerIndex);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < (exam?.questions.length || 0) - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const handleCompleteExam = () => {
    completeExam(session.id);
    setIsExamCompleted(true);
    stopDetection();
    setTimeout(() => {
      onComplete();
    }, 3000);
  };

  const getProctorStatusColor = () => {
    if (!proctorStatus.faceDetected) return 'bg-red-500';
    if (proctorStatus.multipleFaces) return 'bg-red-500';
    if (!proctorStatus.eyesOnScreen) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getProctorStatusText = () => {
    if (!proctorStatus.faceDetected) return 'No face detected';
    if (proctorStatus.multipleFaces) return 'Multiple faces detected';
    if (!proctorStatus.eyesOnScreen) return 'Eyes off screen';
    return 'All systems normal';
  };

  if (!exam || !currentQuestion) {
    return <div>Loading exam...</div>;
  }

  if (isExamCompleted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white rounded-lg shadow-lg p-8 text-center max-w-md">
          <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Exam Completed!</h2>
          <p className="text-gray-600 mb-4">Your responses have been submitted successfully.</p>
          <p className="text-sm text-gray-500">Redirecting to dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-xl font-semibold text-gray-900">{exam.title}</h1>
              <p className="text-sm text-gray-600">{exam.subject}</p>
            </div>
            
            <div className="flex items-center space-x-6">
              {/* Timer */}
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-blue-600" />
                <span className="text-lg font-mono font-semibold text-gray-900">
                  {formatTime(timeRemaining)}
                </span>
              </div>
              
              {/* Proctor Status */}
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${getProctorStatusColor()}`}></div>
                <span className="text-sm text-gray-600">{getProctorStatusText()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Violation Alert */}
            {showViolationAlert && proctorStatus.lastViolation && (
              <div className="mb-4 bg-red-50 border border-red-200 rounded-md p-4">
                <div className="flex items-center">
                  <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
                  <div>
                    <h3 className="text-sm font-medium text-red-800">Proctoring Violation Detected</h3>
                    <p className="text-sm text-red-600">{proctorStatus.lastViolation.description}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Question */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="mb-4">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium text-gray-900">
                    Question {currentQuestionIndex + 1} of {exam.questions.length}
                  </h2>
                  <span className="text-sm text-gray-600">{currentQuestion.points} points</span>
                </div>
                
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${((currentQuestionIndex + 1) / exam.questions.length) * 100}%` }}
                  ></div>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  {currentQuestion.question}
                </h3>
                
                <div className="space-y-3">
                  {currentQuestion.options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleAnswerSelect(index)}
                      className={`w-full text-left p-4 border rounded-lg transition-colors ${
                        selectedAnswer === index
                          ? 'border-blue-500 bg-blue-50 text-blue-900'
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      <div className="flex items-center">
                        <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                          selectedAnswer === index
                            ? 'border-blue-500 bg-blue-500'
                            : 'border-gray-300'
                        }`}>
                          {selectedAnswer === index && (
                            <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
                          )}
                        </div>
                        <span>{option}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Navigation */}
              <div className="flex justify-between">
                <button
                  onClick={handlePreviousQuestion}
                  disabled={currentQuestionIndex === 0}
                  className="px-4 py-2 text-gray-600 border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Previous
                </button>
                
                <div className="space-x-3">
                  {currentQuestionIndex === exam.questions.length - 1 ? (
                    <button
                      onClick={handleCompleteExam}
                      className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
                    >
                      Submit Exam
                    </button>
                  ) : (
                    <button
                      onClick={handleNextQuestion}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      Next
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Camera Feed */}
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center">
                <Camera className="h-4 w-4 mr-2" />
                Live Monitoring
              </h3>
              <div className="aspect-video bg-gray-900 rounded-md overflow-hidden">
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  autoPlay
                  muted
                  playsInline
                />
              </div>
              <div className="mt-2 text-xs text-gray-600 text-center">
                Proctoring active
              </div>
            </div>

            {/* Proctor Status Details */}
            <div className="bg-white rounded-lg shadow-md p-4 mb-6">
              <h3 className="text-sm font-medium text-gray-900 mb-3">System Status</h3>
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="flex items-center">
                    <Eye className="h-3 w-3 mr-1" />
                    Face Detection
                  </span>
                  <span className={proctorStatus.faceDetected ? 'text-green-600' : 'text-red-600'}>
                    {proctorStatus.faceDetected ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center">
                    <Users className="h-3 w-3 mr-1" />
                    Multiple Faces
                  </span>
                  <span className={proctorStatus.multipleFaces ? 'text-red-600' : 'text-green-600'}>
                    {proctorStatus.multipleFaces ? 'Detected' : 'Clear'}
                  </span>
                </div>
              </div>
            </div>

            {/* Question Navigator */}
            <div className="bg-white rounded-lg shadow-md p-4">
              <h3 className="text-sm font-medium text-gray-900 mb-3">Questions</h3>
              <div className="grid grid-cols-5 gap-2">
                {exam.questions.map((_, index) => {
                  const isAnswered = session.answers[exam.questions[index].id] !== undefined;
                  const isCurrent = index === currentQuestionIndex;
                  
                  return (
                    <button
                      key={index}
                      onClick={() => setCurrentQuestionIndex(index)}
                      className={`w-8 h-8 text-xs rounded ${
                        isCurrent
                          ? 'bg-blue-600 text-white'
                          : isAnswered
                          ? 'bg-green-100 text-green-800 border border-green-300'
                          : 'bg-gray-100 text-gray-600 border border-gray-300'
                      }`}
                    >
                      {index + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};