import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useExam } from '../../contexts/ExamContext';
import { BookOpen, Clock, Play, Hash } from 'lucide-react';
import { ExamTaking } from './ExamTaking';

export const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  const { joinExam, examSessions } = useExam();
  const [examCode, setExamCode] = useState('');
  const [currentSession, setCurrentSession] = useState<any>(null);
  const [error, setError] = useState('');

  const handleJoinExam = () => {
    if (!examCode.trim()) {
      setError('Please enter an exam code');
      return;
    }

    const session = joinExam(examCode.toUpperCase(), user!.id);
    if (session) {
      setCurrentSession(session);
      setError('');
    } else {
      setError('Invalid exam code or exam not available');
    }
  };

  const studentSessions = examSessions.filter(s => s.studentId === user!.id);
  const completedSessions = studentSessions.filter(s => s.isCompleted);
  const activeSessions = studentSessions.filter(s => !s.isCompleted);

  if (currentSession) {
    return <ExamTaking session={currentSession} onComplete={() => setCurrentSession(null)} />;
  }

  return (
    <div className="px-4 py-6 sm:px-0">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Student Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.name}!</p>
      </div>

      {/* Join Exam Section */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
          <Hash className="h-5 w-5 mr-2 text-blue-600" />
          Join Exam
        </h2>
        
        <div className="flex space-x-4">
          <div className="flex-1">
            <input
              type="text"
              value={examCode}
              onChange={(e) => setExamCode(e.target.value)}
              placeholder="Enter exam code (e.g., ABC123)"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <button
            onClick={handleJoinExam}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center"
          >
            <Play className="h-4 w-4 mr-2" />
            Join Exam
          </button>
        </div>
        
        {error && (
          <p className="mt-2 text-red-600 text-sm">{error}</p>
        )}
      </div>

      {/* Active Exams */}
      {activeSessions.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
            <Clock className="h-5 w-5 mr-2 text-green-600" />
            Active Exams
          </h2>
          
          <div className="space-y-3">
            {activeSessions.map(session => (
              <div key={session.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div>
                  <h3 className="font-medium text-gray-900">Exam ID: {session.examId}</h3>
                  <p className="text-sm text-gray-600">Started: {new Date(session.startTime).toLocaleString()}</p>
                </div>
                <button
                  onClick={() => setCurrentSession(session)}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  Resume
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Completed Exams */}
      {completedSessions.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
            <BookOpen className="h-5 w-5 mr-2 text-gray-600" />
            Completed Exams
          </h2>
          
          <div className="space-y-3">
            {completedSessions.map(session => (
              <div key={session.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div>
                  <h3 className="font-medium text-gray-900">Exam ID: {session.examId}</h3>
                  <p className="text-sm text-gray-600">
                    Completed: {new Date(session.endTime!).toLocaleString()}
                  </p>
                  {session.violations.length > 0 && (
                    <p className="text-sm text-amber-600">
                      {session.violations.length} violation(s) detected
                    </p>
                  )}
                </div>
                <div className="text-right">
                  <p className="font-semibold text-lg text-blue-600">
                    {session.score !== undefined ? `${session.score} pts` : 'Grading...'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {studentSessions.length === 0 && (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <BookOpen className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No exams yet</h3>
          <p className="text-gray-600">Enter an exam code above to get started with your first exam.</p>
        </div>
      )}
    </div>
  );
};