import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useExam } from '../../contexts/ExamContext';
import { Plus, BookOpen, Users, BarChart3, Eye } from 'lucide-react';
import { CreateExam } from './CreateExam';
import { MonitorExam } from './MonitorExam';
import { ExamResults } from './ExamResults';

export const TeacherDashboard: React.FC = () => {
  const { user } = useAuth();
  const { exams, examSessions } = useExam();
  const [activeTab, setActiveTab] = useState<'overview' | 'create' | 'monitor' | 'results'>('overview');
  const [selectedExam, setSelectedExam] = useState<string | null>(null);

  const teacherExams = exams.filter(exam => exam.createdBy === user!.id);
  const totalSessions = examSessions.filter(session => 
    teacherExams.some(exam => exam.id === session.examId)
  ).length;
  const activeSessions = examSessions.filter(session => 
    !session.isCompleted && teacherExams.some(exam => exam.id === session.examId)
  ).length;
  const completedSessions = examSessions.filter(session => 
    session.isCompleted && teacherExams.some(exam => exam.id === session.examId)
  ).length;

  const renderTabContent = () => {
    switch (activeTab) {
      case 'create':
        return <CreateExam onComplete={() => setActiveTab('overview')} />;
      case 'monitor':
        return <MonitorExam examId={selectedExam} />;
      case 'results':
        return <ExamResults examId={selectedExam} />;
      default:
        return (
          <div className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center">
                  <BookOpen className="h-8 w-8 text-blue-600" />
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-500">Total Exams</h3>
                    <p className="text-2xl font-bold text-gray-900">{teacherExams.length}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center">
                  <Users className="h-8 w-8 text-green-600" />
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-500">Active Sessions</h3>
                    <p className="text-2xl font-bold text-gray-900">{activeSessions}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center">
                  <BarChart3 className="h-8 w-8 text-purple-600" />
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-500">Completed</h3>
                    <p className="text-2xl font-bold text-gray-900">{completedSessions}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center">
                  <Users className="h-8 w-8 text-orange-600" />
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-gray-500">Total Sessions</h3>
                    <p className="text-2xl font-bold text-gray-900">{totalSessions}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Recent Exams */}
            <div className="bg-white rounded-lg shadow-md">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-800">Your Exams</h2>
              </div>
              
              <div className="p-6">
                {teacherExams.length === 0 ? (
                  <div className="text-center py-8">
                    <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No exams created yet</h3>
                    <p className="text-gray-600 mb-4">Get started by creating your first exam.</p>
                    <button
                      onClick={() => setActiveTab('create')}
                      className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                    >
                      Create Exam
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {teacherExams.map(exam => {
                      const currentExamSessions = examSessions.filter(s => s.examId === exam.id);
                      const activeCount = currentExamSessions.filter(s => !s.isCompleted).length;
                      const completedCount = currentExamSessions.filter(s => s.isCompleted).length;
                      
                      return (
                        <div key={exam.id} className="border border-gray-200 rounded-lg p-4">
                          <div className="mb-3">
                            <h3 className="font-medium text-gray-900">{exam.title}</h3>
                            <p className="text-sm text-gray-600">{exam.subject}</p>
                            <p className="text-xs text-gray-500 mt-1">
                              Code: <span className="font-mono font-semibold">{exam.examCode}</span>
                            </p>
                          </div>
                          
                          <div className="text-xs text-gray-600 mb-3">
                            <p>{exam.questions.length} questions • {exam.duration} mins</p>
                            <p>Active: {activeCount} • Completed: {completedCount}</p>
                          </div>
                          
                          <div className="flex space-x-2">
                            <button
                              onClick={() => {
                                setSelectedExam(exam.id);
                                setActiveTab('monitor');
                              }}
                              className="flex-1 px-3 py-1 text-xs bg-green-100 text-green-800 rounded hover:bg-green-200 transition-colors flex items-center justify-center"
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              Monitor
                            </button>
                            <button
                              onClick={() => {
                                setSelectedExam(exam.id);
                                setActiveTab('results');
                              }}
                              className="flex-1 px-3 py-1 text-xs bg-blue-100 text-blue-800 rounded hover:bg-blue-200 transition-colors flex items-center justify-center"
                            >
                              <BarChart3 className="h-3 w-3 mr-1" />
                              Results
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="px-4 py-6 sm:px-0">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Teacher Dashboard</h1>
        <p className="text-gray-600">Welcome back, {user?.name}!</p>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'overview'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('create')}
            className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center ${
              activeTab === 'create'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Plus className="h-4 w-4 mr-1" />
            Create Exam
          </button>
          <button
            onClick={() => setActiveTab('monitor')}
            className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center ${
              activeTab === 'monitor'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Eye className="h-4 w-4 mr-1" />
            Monitor
          </button>
          <button
            onClick={() => setActiveTab('results')}
            className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center ${
              activeTab === 'results'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <BarChart3 className="h-4 w-4 mr-1" />
            Results
          </button>
        </nav>
      </div>

      {renderTabContent()}
    </div>
  );
};