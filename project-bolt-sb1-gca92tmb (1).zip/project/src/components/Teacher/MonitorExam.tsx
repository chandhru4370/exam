import React, { useEffect, useState } from 'react';
import { useExam } from '../../contexts/ExamContext';
import { ExamSession, Violation } from '../../types';
import { AlertTriangle, Eye, EyeOff, Users, Clock, User } from 'lucide-react';
import { format } from 'date-fns';

interface MonitorExamProps {
  examId: string | null;
}

export const MonitorExam: React.FC<MonitorExamProps> = ({ examId }) => {
  const { exams, examSessions } = useExam();
  const [selectedExamId, setSelectedExamId] = useState(examId);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const exam = selectedExamId ? exams.find(e => e.id === selectedExamId) : null;
  const sessions = selectedExamId 
    ? examSessions.filter(s => s.examId === selectedExamId && !s.isCompleted)
    : [];

  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      // In a real app, this would fetch updated data from the server
    }, 5000);

    return () => clearInterval(interval);
  }, [autoRefresh]);

  const getViolationIcon = (type: Violation['type']) => {
    switch (type) {
      case 'no_face':
        return <EyeOff className="h-4 w-4" />;
      case 'multiple_faces':
        return <Users className="h-4 w-4" />;
      case 'eyes_off_screen':
        return <Eye className="h-4 w-4" />;
      default:
        return <AlertTriangle className="h-4 w-4" />;
    }
  };

  const getViolationColor = (type: Violation['type']) => {
    switch (type) {
      case 'no_face':
      case 'multiple_faces':
        return 'text-red-600 bg-red-50';
      case 'eyes_off_screen':
        return 'text-amber-600 bg-amber-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  if (!selectedExamId) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Monitor Live Exam</h2>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Exam to Monitor
          </label>
          <select
            value=""
            onChange={(e) => setSelectedExamId(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Choose an exam...</option>
            {exams.map(exam => (
              <option key={exam.id} value={exam.id}>
                {exam.title} - {exam.subject}
              </option>
            ))}
          </select>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">Monitor Live Exam</h2>
            {exam && (
              <p className="text-gray-600">{exam.title} - {exam.subject}</p>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={autoRefresh}
                onChange={(e) => setAutoRefresh(e.target.checked)}
                className="mr-2"
              />
              <span className="text-sm text-gray-600">Auto-refresh</span>
            </label>
            
            <select
              value={selectedExamId}
              onChange={(e) => setSelectedExamId(e.target.value)}
              className="px-3 py-1 border border-gray-300 rounded-md text-sm"
            >
              {exams.map(exam => (
                <option key={exam.id} value={exam.id}>
                  {exam.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        {exam && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Clock className="h-6 w-6 text-blue-600 mr-2" />
                <div>
                  <p className="text-sm font-medium text-blue-900">Duration</p>
                  <p className="text-lg font-bold text-blue-600">{exam.duration} min</p>
                </div>
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Users className="h-6 w-6 text-green-600 mr-2" />
                <div>
                  <p className="text-sm font-medium text-green-900">Active Students</p>
                  <p className="text-lg font-bold text-green-600">{sessions.length}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Eye className="h-6 w-6 text-purple-600 mr-2" />
                <div>
                  <p className="text-sm font-medium text-purple-900">Questions</p>
                  <p className="text-lg font-bold text-purple-600">{exam.questions.length}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-amber-50 p-4 rounded-lg">
              <div className="flex items-center">
                <AlertTriangle className="h-6 w-6 text-amber-600 mr-2" />
                <div>
                  <p className="text-sm font-medium text-amber-900">Total Violations</p>
                  <p className="text-lg font-bold text-amber-600">
                    {sessions.reduce((acc, session) => acc + session.violations.length, 0)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Active Sessions */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">Live Student Sessions</h3>
        </div>
        
        <div className="p-6">
          {sessions.length === 0 ? (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No active sessions</h3>
              <p className="text-gray-600">Students will appear here when they join the exam.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Student
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Started
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Progress
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Violations
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {sessions.map((session) => {
                    const answeredCount = Object.keys(session.answers).length;
                    const totalQuestions = exam?.questions.length || 0;
                    const progress = totalQuestions > 0 ? (answeredCount / totalQuestions) * 100 : 0;
                    const recentViolations = session.violations.slice(-3);
                    
                    return (
                      <tr key={session.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <User className="h-8 w-8 text-gray-400 mr-3" />
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                Student {session.studentId.slice(0, 8)}
                              </div>
                              <div className="text-sm text-gray-500">
                                Session {session.id.slice(0, 8)}
                              </div>
                            </div>
                          </div>
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {format(new Date(session.startTime), 'MMM dd, HH:mm')}
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-full bg-gray-200 rounded-full h-2 mr-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full"
                                style={{ width: `${progress}%` }}
                              />
                            </div>
                            <span className="text-sm text-gray-600">
                              {answeredCount}/{totalQuestions}
                            </span>
                          </div>
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center space-x-2">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              session.violations.length === 0 
                                ? 'bg-green-100 text-green-800'
                                : session.violations.length > 5
                                ? 'bg-red-100 text-red-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}>
                              {session.violations.length} violations
                            </span>
                            
                            <div className="flex space-x-1">
                              {recentViolations.map((violation, index) => (
                                <div
                                  key={index}
                                  className={`p-1 rounded ${getViolationColor(violation.type)}`}
                                  title={violation.description}
                                >
                                  {getViolationIcon(violation.type)}
                                </div>
                              ))}
                            </div>
                          </div>
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded-full">
                            Active
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Recent Violations */}
      {sessions.length > 0 && (
        <div className="bg-white rounded-lg shadow-md">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-800">Recent Violations</h3>
          </div>
          
          <div className="p-6">
            <div className="space-y-3">
              {sessions.flatMap(session => 
                session.violations.slice(-5).map(violation => ({
                  ...violation,
                  sessionId: session.id,
                  studentId: session.studentId
                }))
              ).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 10).map((violation) => (
                <div key={violation.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                  <div className="flex items-center">
                    <div className={`p-2 rounded-full mr-3 ${getViolationColor(violation.type)}`}>
                      {getViolationIcon(violation.type)}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        Student {violation.studentId.slice(0, 8)}
                      </p>
                      <p className="text-sm text-gray-600">{violation.description}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">
                      {format(new Date(violation.timestamp), 'HH:mm:ss')}
                    </p>
                  </div>
                </div>
              ))}
              
              {sessions.every(session => session.violations.length === 0) && (
                <div className="text-center py-8">
                  <AlertTriangle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No violations detected</h3>
                  <p className="text-gray-600">All students are following exam protocols.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};