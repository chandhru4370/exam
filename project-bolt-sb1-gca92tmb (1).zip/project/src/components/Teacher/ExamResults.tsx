import React, { useState } from 'react';
import { useExam } from '../../contexts/ExamContext';
import { BarChart3, User, Download, Eye } from 'lucide-react';
import { format } from 'date-fns';

interface ExamResultsProps {
  examId: string | null;
}

export const ExamResults: React.FC<ExamResultsProps> = ({ examId }) => {
  const { exams, getExamResults } = useExam();
  const [selectedExamId, setSelectedExamId] = useState(examId);
  const [selectedSession, setSelectedSession] = useState<string | null>(null);

  const exam = selectedExamId ? exams.find(e => e.id === selectedExamId) : null;
  const results = selectedExamId ? getExamResults(selectedExamId) : [];

  const calculateStats = () => {
    if (results.length === 0) return null;

    const scores = results.map(r => r.score || 0);
    const totalPossible = exam?.questions.reduce((sum, q) => sum + q.points, 0) || 1;
    const percentages = scores.map(s => (s / totalPossible) * 100);

    return {
      totalStudents: results.length,
      averageScore: scores.reduce((sum, score) => sum + score, 0) / scores.length,
      averagePercentage: percentages.reduce((sum, pct) => sum + pct, 0) / percentages.length,
      highestScore: Math.max(...scores),
      lowestScore: Math.min(...scores),
      totalViolations: results.reduce((sum, r) => sum + r.violations.length, 0),
    };
  };

  const stats = calculateStats();

  if (!selectedExamId) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Exam Results</h2>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Select Exam to View Results
          </label>
          <select
            value=""
            onChange={(e) => setSelectedExamId(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Choose an exam...</option>
            {exams.map(exam => (
              <option key={exam.id} value={exam.id}>
                {exam.title} - {exam.subject}
              </option>
            ))}
          </select>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h2 className="text-xl font-semibold text-gray-800">Exam Results</h2>
            {exam && (
              <p className="text-gray-600">{exam.title} - {exam.subject}</p>
            )}
          </div>
          
          <select
            value={selectedExamId}
            onChange={(e) => setSelectedExamId(e.target.value)}
            className="px-3 py-1 border border-gray-300 rounded-md text-sm"
          >
            {exams.map(exam => (
              <option key={exam.id} value={exam.id}>
                {exam.title}
              </option>
            ))}
          </select>
        </div>

        {/* Statistics */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center">
                <User className="h-6 w-6 text-blue-600 mr-2" />
                <div>
                  <p className="text-sm font-medium text-blue-900">Students</p>
                  <p className="text-lg font-bold text-blue-600">{stats.totalStudents}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center">
                <BarChart3 className="h-6 w-6 text-green-600 mr-2" />
                <div>
                  <p className="text-sm font-medium text-green-900">Avg Score</p>
                  <p className="text-lg font-bold text-green-600">
                    {stats.averageScore.toFixed(1)}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-purple-50 p-4 rounded-lg">
              <div>
                <p className="text-sm font-medium text-purple-900">Avg %</p>
                <p className="text-lg font-bold text-purple-600">
                  {stats.averagePercentage.toFixed(1)}%
                </p>
              </div>
            </div>
            
            <div className="bg-amber-50 p-4 rounded-lg">
              <div>
                <p className="text-sm font-medium text-amber-900">Highest</p>
                <p className="text-lg font-bold text-amber-600">{stats.highestScore}</p>
              </div>
            </div>
            
            <div className="bg-red-50 p-4 rounded-lg">
              <div>
                <p className="text-sm font-medium text-red-900">Lowest</p>
                <p className="text-lg font-bold text-red-600">{stats.lowestScore}</p>
              </div>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <div>
                <p className="text-sm font-medium text-gray-900">Violations</p>
                <p className="text-lg font-bold text-gray-600">{stats.totalViolations}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Results Table */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-gray-800">Student Results</h3>
          {results.length > 0 && (
            <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm">
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </button>
          )}
        </div>
        
        <div className="p-6">
          {results.length === 0 ? (
            <div className="text-center py-8">
              <BarChart3 className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No results yet</h3>
              <p className="text-gray-600">Results will appear here once students complete the exam.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Student
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Score
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Percentage
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Duration
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Violations
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {results.map((result) => {
                    const totalPossible = exam?.questions.reduce((sum, q) => sum + q.points, 0) || 1;
                    const percentage = ((result.score || 0) / totalPossible) * 100;
                    const duration = result.endTime 
                      ? Math.floor((new Date(result.endTime).getTime() - new Date(result.startTime).getTime()) / 60000)
                      : 0;
                    
                    return (
                      <tr key={result.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <User className="h-8 w-8 text-gray-400 mr-3" />
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                Student {result.studentId.slice(0, 8)}
                              </div>
                              <div className="text-sm text-gray-500">
                                {format(new Date(result.startTime), 'MMM dd, HH:mm')}
                              </div>
                            </div>
                          </div>
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            {result.score || 0} / {totalPossible}
                          </div>
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            percentage >= 80 
                              ? 'bg-green-100 text-green-800'
                              : percentage >= 60
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {percentage.toFixed(1)}%
                          </span>
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {duration} minutes
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            result.violations.length === 0 
                              ? 'bg-green-100 text-green-800'
                              : result.violations.length > 5
                              ? 'bg-red-100 text-red-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {result.violations.length} violations
                          </span>
                        </td>
                        
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => setSelectedSession(result.id)}
                            className="text-blue-600 hover:text-blue-900 flex items-center"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View Details
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Session Details Modal */}
      {selectedSession && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-screen overflow-y-auto m-4">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-800">Session Details</h3>
              <button
                onClick={() => setSelectedSession(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
            
            <div className="p-6">
              {(() => {
                const session = results.find(r => r.id === selectedSession);
                if (!session) return null;
                
                return (
                  <div className="space-y-6">
                    {/* Session Info */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium text-gray-900">Student ID</h4>
                        <p className="text-gray-600">{session.studentId}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Score</h4>
                        <p className="text-gray-600">{session.score} points</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">Start Time</h4>
                        <p className="text-gray-600">{format(new Date(session.startTime), 'MMM dd, yyyy HH:mm')}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">End Time</h4>
                        <p className="text-gray-600">
                          {session.endTime ? format(new Date(session.endTime), 'MMM dd, yyyy HH:mm') : 'Not completed'}
                        </p>
                      </div>
                    </div>
                    
                    {/* Violations */}
                    {session.violations.length > 0 && (
                      <div>
                        <h4 className="font-medium text-gray-900 mb-3">Violations ({session.violations.length})</h4>
                        <div className="space-y-2 max-h-60 overflow-y-auto">
                          {session.violations.map((violation) => (
                            <div key={violation.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                              <div>
                                <p className="text-sm font-medium text-red-900">{violation.type.replace('_', ' ').toUpperCase()}</p>
                                <p className="text-sm text-red-700">{violation.description}</p>
                              </div>
                              <p className="text-xs text-red-600">
                                {format(new Date(violation.timestamp), 'HH:mm:ss')}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {/* Answers */}
                    <div>
                      <h4 className="font-medium text-gray-900 mb-3">Answers</h4>
                      <div className="space-y-3 max-h-60 overflow-y-auto">
                        {exam?.questions.map((question, index) => {
                          const userAnswer = session.answers[question.id];
                          const isCorrect = userAnswer === question.correctAnswer;
                          
                          return (
                            <div key={question.id} className="border rounded-lg p-3">
                              <div className="flex justify-between items-start mb-2">
                                <h5 className="font-medium text-gray-900">Question {index + 1}</h5>
                                <span className={`px-2 py-1 text-xs rounded ${
                                  isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                }`}>
                                  {isCorrect ? 'Correct' : 'Incorrect'}
                                </span>
                              </div>
                              <p className="text-sm text-gray-700 mb-2">{question.question}</p>
                              <div className="text-sm">
                                <p className="text-gray-600">
                                  Student answer: {userAnswer !== undefined ? question.options[userAnswer] : 'No answer'}
                                </p>
                                <p className="text-green-700">
                                  Correct answer: {question.options[question.correctAnswer]}
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};