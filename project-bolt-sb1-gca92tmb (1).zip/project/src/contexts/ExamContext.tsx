import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Exam, ExamSession, Question } from '../types';

interface ExamContextType {
  exams: Exam[];
  examSessions: ExamSession[];
  createExam: (examData: Omit<Exam, 'id' | 'examCode'>) => void;
  joinExam: (examCode: string, studentId: string) => ExamSession | null;
  submitAnswer: (sessionId: string, questionId: string, answer: number) => void;
  completeExam: (sessionId: string) => void;
  getExamResults: (examId: string) => ExamSession[];
}

const ExamContext = createContext<ExamContextType | undefined>(undefined);

export const useExam = () => {
  const context = useContext(ExamContext);
  if (context === undefined) {
    throw new Error('useExam must be used within an ExamProvider');
  }
  return context;
};

interface ExamProviderProps {
  children: ReactNode;
}

export const ExamProvider: React.FC<ExamProviderProps> = ({ children }) => {
  const [exams, setExams] = useState<Exam[]>([]);
  const [examSessions, setExamSessions] = useState<ExamSession[]>([]);

  useEffect(() => {
    const savedExams = localStorage.getItem('exams');
    const savedSessions = localStorage.getItem('examSessions');
    
    if (savedExams) {
      setExams(JSON.parse(savedExams));
    }
    
    if (savedSessions) {
      setExamSessions(JSON.parse(savedSessions));
    }
  }, []);

  const generateExamCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const createExam = (examData: Omit<Exam, 'id' | 'examCode'>) => {
    const newExam: Exam = {
      ...examData,
      id: Math.random().toString(36).substring(7),
      examCode: generateExamCode(),
    };
    
    const updatedExams = [...exams, newExam];
    setExams(updatedExams);
    localStorage.setItem('exams', JSON.stringify(updatedExams));
  };

  const joinExam = (examCode: string, studentId: string): ExamSession | null => {
    const exam = exams.find(e => e.examCode === examCode && e.isActive);
    if (!exam) return null;
    
    // Check if student already has a session for this exam
    const existingSession = examSessions.find(s => s.examId === exam.id && s.studentId === studentId);
    if (existingSession) return existingSession;
    
    const newSession: ExamSession = {
      id: Math.random().toString(36).substring(7),
      examId: exam.id,
      studentId,
      startTime: new Date().toISOString(),
      answers: {},
      violations: [],
      isCompleted: false,
    };
    
    const updatedSessions = [...examSessions, newSession];
    setExamSessions(updatedSessions);
    localStorage.setItem('examSessions', JSON.stringify(updatedSessions));
    
    return newSession;
  };

  const submitAnswer = (sessionId: string, questionId: string, answer: number) => {
    const updatedSessions = examSessions.map(session => {
      if (session.id === sessionId) {
        return {
          ...session,
          answers: {
            ...session.answers,
            [questionId]: answer
          }
        };
      }
      return session;
    });
    
    setExamSessions(updatedSessions);
    localStorage.setItem('examSessions', JSON.stringify(updatedSessions));
  };

  const completeExam = (sessionId: string) => {
    const updatedSessions = examSessions.map(session => {
      if (session.id === sessionId) {
        const exam = exams.find(e => e.id === session.examId);
        let score = 0;
        
        if (exam) {
          exam.questions.forEach(question => {
            if (session.answers[question.id] === question.correctAnswer) {
              score += question.points;
            }
          });
        }
        
        return {
          ...session,
          endTime: new Date().toISOString(),
          isCompleted: true,
          score,
        };
      }
      return session;
    });
    
    setExamSessions(updatedSessions);
    localStorage.setItem('examSessions', JSON.stringify(updatedSessions));
  };

  const getExamResults = (examId: string): ExamSession[] => {
    return examSessions.filter(session => session.examId === examId && session.isCompleted);
  };

  return (
    <ExamContext.Provider value={{
      exams,
      examSessions,
      createExam,
      joinExam,
      submitAnswer,
      completeExam,
      getExamResults,
    }}>
      {children}
    </ExamContext.Provider>
  );
};