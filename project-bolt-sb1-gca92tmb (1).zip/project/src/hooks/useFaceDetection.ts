import { useEffect, useRef, useState } from 'react';
import * as tf from '@tensorflow/tfjs';
import '@tensorflow/tfjs-backend-webgl';
import * as faceLandmarksDetection from '@tensorflow-models/face-landmarks-detection';
import { ProctorStatus, Violation } from '../types';

export const useFaceDetection = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [detector, setDetector] = useState<faceLandmarksDetection.FaceLandmarksDetector | null>(null);
  const [proctorStatus, setProctorStatus] = useState<ProctorStatus>({
    faceDetected: false,
    eyesOnScreen: false,
    multipleFaces: false,
  });
  const [violations, setViolations] = useState<Violation[]>([]);
  const [isInitialized, setIsInitialized] = useState(false);
  const animationRef = useRef<number>();
  const noFaceTimeoutRef = useRef<NodeJS.Timeout>();
  const lastViolationRef = useRef<{ [key: string]: number }>({});

  const addViolation = (type: Violation['type'], description: string) => {
    const now = Date.now();
    const lastTime = lastViolationRef.current[type] || 0;
    
    // Prevent spam violations (minimum 2 seconds between same type)
    if (now - lastTime < 2000) return;
    
    const violation: Violation = {
      id: Math.random().toString(36).substring(7),
      type,
      timestamp: new Date().toISOString(),
      description,
    };
    
    setViolations(prev => [...prev, violation]);
    setProctorStatus(prev => ({ ...prev, lastViolation: violation }));
    lastViolationRef.current[type] = now;
  };

  const initializeCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: 640, 
          height: 480,
          facingMode: 'user'
        } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      
      return true;
    } catch (error) {
      console.error('Error accessing camera:', error);
      return false;
    }
  };

  const initializeFaceDetection = async () => {
    try {
      await tf.ready();
      
      const model = faceLandmarksDetection.SupportedModels.MediaPipeFaceMesh;
      const detectorConfig = {
        runtime: 'tfjs' as const,
        refineLandmarks: true,
      };
      
      const det = await faceLandmarksDetection.createDetector(model, detectorConfig);
      setDetector(det);
      setIsInitialized(true);
      
      return true;
    } catch (error) {
      console.error('Error initializing face detection:', error);
      return false;
    }
  };

  const detectFaces = async () => {
    if (!detector || !videoRef.current) return;

    try {
      const faces = await detector.estimateFaces(videoRef.current);
      const faceCount = faces.length;
      
      // Update proctor status
      setProctorStatus(prev => ({
        ...prev,
        faceDetected: faceCount > 0,
        multipleFaces: faceCount > 1,
        eyesOnScreen: faceCount === 1, // Simplified eye detection
      }));

      // Handle violations
      if (faceCount === 0) {
        if (!noFaceTimeoutRef.current) {
          noFaceTimeoutRef.current = setTimeout(() => {
            addViolation('no_face', 'No face detected for extended period');
          }, 3000);
        }
      } else {
        if (noFaceTimeoutRef.current) {
          clearTimeout(noFaceTimeoutRef.current);
          noFaceTimeoutRef.current = undefined;
        }
      }

      if (faceCount > 1) {
        addViolation('multiple_faces', `${faceCount} faces detected`);
      }

    } catch (error) {
      console.error('Face detection error:', error);
    }
  };

  const startDetection = () => {
    const detect = () => {
      detectFaces();
      animationRef.current = requestAnimationFrame(detect);
    };
    detect();
  };

  const stopDetection = () => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
    if (noFaceTimeoutRef.current) {
      clearTimeout(noFaceTimeoutRef.current);
    }
    
    // Stop camera
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
    }
  };

  const initialize = async () => {
    const cameraInitialized = await initializeCamera();
    if (cameraInitialized) {
      await initializeFaceDetection();
    }
  };

  useEffect(() => {
    return () => {
      stopDetection();
    };
  }, []);

  return {
    videoRef,
    proctorStatus,
    violations,
    isInitialized,
    initialize,
    startDetection,
    stopDetection,
  };
};