export interface User {
  id: string;
  email: string;
  role: 'student' | 'teacher';
  name: string;
}

export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  points: number;
}

export interface Exam {
  id: string;
  title: string;
  subject: string;
  date: string;
  time: string;
  duration: number; // in minutes
  questions: Question[];
  createdBy: string;
  examCode: string;
  isActive: boolean;
}

export interface ExamSession {
  id: string;
  examId: string;
  studentId: string;
  startTime: string;
  endTime?: string;
  answers: Record<string, number>;
  violations: Violation[];
  isCompleted: boolean;
  score?: number;
}

export interface Violation {
  id: string;
  type: 'no_face' | 'multiple_faces' | 'eyes_off_screen' | 'tab_switch';
  timestamp: string;
  description: string;
}

export interface ProctorStatus {
  faceDetected: boolean;
  eyesOnScreen: boolean;
  multipleFaces: boolean;
  lastViolation?: Violation;
}